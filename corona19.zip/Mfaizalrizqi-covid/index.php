<?php
session_start();
include 'config/Controller.php';
error_log(0);
error_reporting(0);
$covid = new Corona19();
$table = 'tb_user';
$cek_field = $_POST['nama'];
$field = array(
        'nama' => @$_POST['nama'],
        'jk' => @$_POST['jk'],
        'usia' => @$_POST['usia'],
);
$redirect = 'master/HalamanUsers.php';
if (isset($_POST['next'])) {
$_SESSION['nama'] = $_POST['nama'];  
$_SESSION['jk'] = $_POST['jk'];
$_SESSION['usia'] = $_POST['usia'];        
    if ($cek_field == "") {
        echo  "<script>alert('Silahkan isi field terlebih dahulu!');
    document.location.href='index.php'</script>";
    } else {
        $covid->insert($table, $field, $redirect);
    }
}
?>
<html>
    <head>
        <style>
            body {
    margin : 0;
    padding: 0;
    font-family: sans-serif;
    background-image: url('img/covid.jpg');
    background-size: cover;
}
.login-box{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
}
.textbox{
    width: 120%;
    overflow: hidden;
    font-size: 20px;
    padding: 10px 0;
    margin: 10px 0;
    border-bottom: 3px solid  #cdb79e;
}
.textbox input{
    border:none;
    outline: none;
    background: transparent;
    font-size: 20px;
    color: white;
    width: 100%;
    float: left;
    margin: 0 10px;
    height: 20px;
}
.btn{
    width: 90%;
    overflow: hidden;
    font-size: 20px;
    padding: 8px 0;
    margin: 30px 10px;
    border-radius: 20px;
    background:transparent;
    color: white;
}
.btn:hover{
    color: black;
    background:#ffff;
    box-shadow: 0 0 15px 5px #ffff;
}
.kotak {
    width: 450px;
    height: 450px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background:transparent;
    opacity: 90%;
    border: 5px solid #cdb79e;
    border-radius: 80px;
    }
     .position2 {
            margin-top: 180px;
            position: fixed;
            margin-left: 518px;
            color: white;
        }
.textbox1 input{
    border:none;
    outline: none;
    background: white;
    font-size: 20px;
    color: white;
    width: 100%;
    float: left;
    margin: 0 10px;
    border-radius: 40px; 
    text-align: center;

}
h1{
    color: gray;
    border-bottom: 3px solid  #cdb79e;
    background-color: black;
}
}
        </style>
        <meta charset="utf-8">
        <title>Halaman Login</title>
        <center>
        <h1>Selamat Datang</h1>
    </center>
    </head>
    <form method="post">
        <body>
            <div class="kotak">
            <div class="login-box">
                <P>Masukan Nama Anda : </P>
                <div class="textbox">
                    <input type="text" name="nama" placeholder="masukan nama anda" required>
                </div>
        <div>
            <p><label for="jk">Jenis Kelamin :</label></p>
            <p><input type="radio" name="jk" value="L">Laki-laki</p>
            <p><input type="radio" name="jk" value="P">Perempuan</p>
         </div>
        
                <div class="textbox1">
                    <p>Usia :</p>
                    <input type="number" name="usia"  required>
                </div>
                <div>

                   <input type="submit" name="next" value="Mulai" class="btn">
            </div>
        </div>
        </body>
    </form>
</html>